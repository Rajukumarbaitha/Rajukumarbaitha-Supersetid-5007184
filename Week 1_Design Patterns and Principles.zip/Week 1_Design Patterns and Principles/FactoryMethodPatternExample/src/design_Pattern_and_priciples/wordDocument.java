package design_Pattern_and_priciples;

public class wordDocument implements DocumentFactory{

    @Override
    public void createDocument() {
        System.out.println("word Document Created...");
    }
    
}


