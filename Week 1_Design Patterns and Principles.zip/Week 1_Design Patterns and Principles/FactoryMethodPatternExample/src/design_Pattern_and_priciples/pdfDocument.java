package design_Pattern_and_priciples;

public class pdfDocument implements DocumentFactory{

    @Override
    public void createDocument() {
        System.out.println("pdf Document Created.");
    }
    
}
