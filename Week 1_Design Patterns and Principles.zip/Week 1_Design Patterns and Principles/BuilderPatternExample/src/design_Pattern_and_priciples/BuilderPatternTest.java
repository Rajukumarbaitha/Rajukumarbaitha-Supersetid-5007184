package design_Pattern_and_priciples;

public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create a basic computer
        Computer basicComputer = new Computer.Builder()
                .CPU("Intel i3")
                .RAM("8GB")
                .storage("256GB SSD")
                .build();
        System.out.println("Basic Computer: " + basicComputer);

        // Create a high-end gaming computer
        Computer gamingComputer = new Computer.Builder()
                .CPU("Intel i9")
                .RAM("32GB")
                .storage("1TB NVMe SSD")
                .GPU("NVIDIA RTX 3080")
                .operatingSystem("Windows 10")
                .build();
        System.out.println("Gaming Computer: " + gamingComputer);

        // Create a custom computer with only specific parts
        Computer customComputer = new Computer.Builder()
                .CPU("AMD Ryzen 7")
                .RAM("16GB")
                .GPU("AMD Radeon RX 6700 XT")
                .build();
        System.out.println("Custom Computer: " + customComputer);
    }
}