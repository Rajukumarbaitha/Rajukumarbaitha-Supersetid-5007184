package design_pattern_and_priciples;

public class SingletonTest {
    public static void main(String[] args) {
        // Get the Logger instance
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Verify that both references point to the same object
        if (logger1 == logger2) {
            System.out.println("Both logger1 and logger2 refer to the same Logger instance.");
        } else {
            System.out.println("Error: logger1 and logger2 are different instances.");
        }

        // Use the logger
        logger1.log("This is a log message from logger1.");
        logger2.log("This is a log message from logger2.");
    }
}