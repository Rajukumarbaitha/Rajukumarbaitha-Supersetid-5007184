package design_Pattern_and_priciples;

public interface Image {
    void display();
}
