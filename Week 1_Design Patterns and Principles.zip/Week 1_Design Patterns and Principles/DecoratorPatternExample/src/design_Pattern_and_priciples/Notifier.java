package design_Pattern_and_priciples;

public interface Notifier {
    void send(String message);
}

