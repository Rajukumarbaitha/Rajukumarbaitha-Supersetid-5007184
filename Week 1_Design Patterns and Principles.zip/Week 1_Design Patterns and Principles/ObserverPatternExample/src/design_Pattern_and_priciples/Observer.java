package design_Pattern_and_priciples;

public interface Observer {
    void update(double stockPrice);
}
