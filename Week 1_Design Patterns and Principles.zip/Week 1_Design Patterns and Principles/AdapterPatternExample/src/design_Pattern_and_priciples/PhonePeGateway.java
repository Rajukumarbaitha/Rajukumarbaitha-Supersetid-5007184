package design_Pattern_and_priciples;

public class PhonePeGateway {
    public boolean sendMoney(double amount) {
        System.out.println("Sending ₹" + amount + " through PhonePe");
        // Simulating money transfer
        return Math.random() < 0.8;  // 80% success rate
    }
}