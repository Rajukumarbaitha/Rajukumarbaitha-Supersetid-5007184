package design_Pattern_and_priciples;

public class PaytmGateway {
    public String initiatePayment(double amount) {
        System.out.println("Initiating payment of ₹" + amount + " through Paytm");
        // Simulating payment processing
        return Math.random() < 0.8 ? "SUCCESS" : "FAILURE";  // 80% success rate
    }
}