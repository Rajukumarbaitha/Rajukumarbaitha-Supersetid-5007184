package design_Pattern_and_priciples;

public interface PaymentProcessor {
    boolean processPayment(double amount);
}